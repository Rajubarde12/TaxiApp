import {createStackNavigator} from '@react-navigation/stack';
import SplashScreen from '../screens/SplashScreen';
import IntroFirstScreen from '../screens/IntroScreens/Intro1';
import IntroSecondScreen from '../screens/IntroScreens/Intro2';
import LoginScreen from '../screens/Auth/LoginScreen';
import RegisterScreen from '../screens/Auth/RegitsterScreen';
import OtpScreen from '../screens/Auth/OtpScreen';
import CompleteProfileScreen from '../screens/Auth/CompletProfile';
import LocationEnableScreen from '../screens/Auth/LocationElableScreen';
import CreateNewpasswordScreen from '../screens/Auth/CreatepasswordScreen';
import HomeScreen from '../screens/MainScreens/HomeScreen';
const Stack = createStackNavigator();
const MyStack = () => {
  const config = {
    animation: 'timing',
    config: {
      stiffness: 1000,
      damping: 500,
      mass: 3,
      overshootClamping: true,
      restDisplacementThreshold: 0.01,
      restSpeedThreshold: 0.01,
    },
  };
  return (
    <Stack.Navigator
      screenOptions={{
        detachPreviousScreen: false, // Keeps the previous screen visible
        gestureEnabled: true,
        transitionSpec: {
          open: {
            animation: 'timing',
            config: {
              stiffness: 2000,
              damping: 100,
              mass: 1,
              overshootClamping: true,
              restDisplacementThreshold: 0.01,
              restSpeedThreshold: 0.01,
            },
          },
          close: {
            animation: 'timing',
            config: {
              stiffness: 2000,
              damping: 100,
              mass: 1,
              overshootClamping: true,
              restDisplacementThreshold: 0.01,
              restSpeedThreshold: 0.01,
            },
          },
        },
        // cardStyleInterpolator: ({current, next, layouts}) => {
        //   const translateX = current.progress.interpolate({
        //     inputRange: [0, 1],
        //     outputRange: [layouts.screen.width, 0], // Current screen slides in
        //   });

        //   const previousTranslateX = next
        //     ? next.progress.interpolate({
        //         inputRange: [0, 1],
        //         outputRange: [0, -layouts.screen.width * 0.3], // Previous screen slides out
        //       })
        //     : 0;

        //   return {
        //     cardStyle: {
        //       transform: [{translateX}],
        //     },
        //     overlayStyle: {
        //       transform: [{translateX: previousTranslateX}],
        //     },
        //   };
        // },
      }}
      initialRouteName="HomeScreen">
      <Stack.Screen
        name="SplashScreen"
        component={SplashScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="IntroFirstScreen"
        component={IntroFirstScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="IntroSecondScreen"
        component={IntroSecondScreen}
        options={{headerShown: false}}
      />

      <Stack.Screen
        name="LoginScreen"
        component={LoginScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="RegisterScreen"
        component={RegisterScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="OtpScreen"
        component={OtpScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="CompleteProfileScreen"
        component={CompleteProfileScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="LocationEnableScreen"
        component={LocationEnableScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="CreateNewpasswordScreen"
        component={CreateNewpasswordScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="HomeScreen"
        component={HomeScreen}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
};
export default MyStack;
