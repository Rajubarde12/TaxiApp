import {View} from 'react-native';
import MapScreen from '../../../components/MapScreen';
import {colors} from '../../../constants/colors';
const HomeScreen = () => {
  return (
    <View style={{flex: 1, backgroundColor: colors.white}}>
      <MapScreen />
    </View>
  );
};
export default HomeScreen;
