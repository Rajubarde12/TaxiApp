const fonts = {
  regular: 'Inter_28pt-Regular',
  bold: 'Inter_28pt-Bold',
  medium: 'Inter_28pt-Medium',
  semi_bold: 'Inter_28pt-SemiBold',
  extra_bold: 'Inter_28pt-ExtraBold',
};
export default fonts;
