const LoginBg = require('../assets/images/LoginBg.jpg');
export {LoginBg};
