export const colors = {
  white: '#fff',
  Off_White: '#F6F6F6',
  black: 'black',
  yellow: '#FECB00',
  grey: '#686868',
  inputBorder: '#E9E9EA',
};
