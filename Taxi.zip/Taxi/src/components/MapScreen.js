import {
  Alert,
  StyleSheet,
  View,
  PermissionsAndroid,
  Platform,
} from 'react-native';
import MapView, {Marker, PROVIDER_GOOGLE} from 'react-native-maps';
import Geolocation from '@react-native-community/geolocation';
import {useEffect, useState} from 'react';
import {LocationMap} from '../constants/svgIcons';
import {GooglePlacesAutocomplete} from 'react-native-google-places-autocomplete';
import GooglePlacesInput from './GooglePlaceInput';

export default () => {
  const [region, setRegion] = useState(null);

  const requestLocationPermission = async () => {
    if (Platform.OS === 'android') {
      const granted = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION,
      ]);

      // Check if both permissions are granted
      return (
        granted['android.permission.ACCESS_FINE_LOCATION'] ===
          PermissionsAndroid.RESULTS.GRANTED &&
        granted['android.permission.ACCESS_COARSE_LOCATION'] ===
          PermissionsAndroid.RESULTS.GRANTED
      );
    }
    return true;
  };
  const handlePlaceSelect = (data, details) => {
    const {lat, lng} = details.geometry.location;

    setRegion({
      latitude: lat,
      longitude: lng,
      latitudeDelta: 0.01, // Adjust zoom level as needed
      longitudeDelta: 0.01,
    });
  };

  useEffect(() => {
    const whati = Geolocation.getCurrentPosition(
      re => {
        const {latitude, longitude} = re?.coords;
        setRegion({
          latitude,
          longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      },
      err => {
        console.log(err);
      },
      {enableHighAccuracy: true, timeout: 500, interval: 500},
    );
    return () => {
      Geolocation.clearWatch(whati);
    };
  }, []);

  return (
    <View style={styles.container}>
      <GooglePlacesInput handlePlaceSelect={handlePlaceSelect} />
      <MapView
        region={region}
        provider={PROVIDER_GOOGLE}
        style={styles.map}
        showsUserLocation={false}>
        {region && (
          <Marker
            coordinate={region}
            title="Your Location"
            description="This is where you are currently located.">
            <LocationMap />
          </Marker>
        )}
      </MapView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  textInputContainer: {
    width: '100%',
    backgroundColor: '#f2f2f2',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  textInput: {
    height: 40,
    fontSize: 16,
    color: '#333',
  },
});
